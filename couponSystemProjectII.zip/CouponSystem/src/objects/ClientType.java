package objects;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public enum ClientType {

	admin,company,customer;
}
