package core.ws;

public class Datechk {

}
